package com.amrita.jpl.cys21041.p2;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;



class QuizGameServer extends QuizGame {
    private List<String> questions;
    private List<QuizGameListener> listeners;

    public QuizGameServer() {
        questions = new ArrayList<>();
        questions.add("Sugar bowl of the world?");
        questions.add("pink city of india?");
        questions.add("Tallest building in the world?");

        listeners = new ArrayList<>();
    }

    @Override
    void startGame() {
        askQuestion();
    }

    @Override
    void askQuestion() {
        Random random = new Random();
        int index = random.nextInt(questions.size());
        String question = questions.get(index);


        for (QuizGameListener listener : listeners) {
            listener.onQuestionAsked(question);
        }
    }

    @Override
    void evaluateAnswer(String answer) {
        boolean isCorrect = false;

        if (answer.equalsIgnoreCase("Cuba")) {
            isCorrect = true;
        } else if (answer.equalsIgnoreCase("Jaipur")) {
            isCorrect = true;
        } else if (answer.equalsIgnoreCase("Burj khalifa")) {
            isCorrect = true;
        }


        for (QuizGameListener listener : listeners) {
            listener.onAnswerEvaluated(isCorrect);
        }
    }

    public void addListener(QuizGameListener listener) {
        listeners.add(listener);
    }
}
public class Server {
    public static void main(String[] args) {
        QuizGameServer server = new QuizGameServer();
        server.startGame();
    }
}
