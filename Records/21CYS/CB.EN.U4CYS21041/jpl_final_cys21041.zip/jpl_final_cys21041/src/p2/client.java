package com.amrita.jpl.cys21041.p2;

interface QuizGameListener {
    void onQuestionAsked(String question);
    void onAnswerEvaluated(boolean isCorrect);
}
class QuizGameClient extends QuizGame implements QuizGameListener {
    private QuizGameServer server;

    public QuizGameClient(QuizGameServer server) {
        this.server = server;
        server.addListener(this);
    }

    @Override
    void startGame() {
        server.startGame();
    }

    @Override
    void askQuestion() {

    }

    @Override
    void evaluateAnswer(String answer) {

    }

    @Override
    public void onQuestionAsked(String question) {
        System.out.println("Question: " + question);

    }

    @Override
    public void onAnswerEvaluated(boolean isCorrect) {
        if (isCorrect) {
            System.out.println("Your answer is correct!");
        } else {
            System.out.println("Your answer is incorrect.");
        }

    }
}
public class Client {
    public static void main(String[] args) {
        QuizGameServer server = new QuizGameServer();
        QuizGameClient client = new QuizGameClient(server);

        client.startGame();

        client.evaluateAnswer("Cuba");
        client.evaluateAnswer("Jaipur");
        client.evaluateAnswer("Antila");
    }
}
